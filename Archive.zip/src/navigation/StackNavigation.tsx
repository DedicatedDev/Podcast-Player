import AppNavigator from "./AppNavigator";
export const MainStackNavigator = () => {
    return (
        <AppNavigator/>
    )
}